let jogador;
let alimentos = [];
let tipos = ["🌽", "🍅", "🥕"];
let pedidos = [];
let inventario = {};
let cidadeX;
let vidas = 3;
let estado = "jogando";
let entregas = 0;
let obstaculos = [];

function setup() {
  createCanvas(1000, 550);
  jogador = new Trator();
  cidadeX = width - 150;
  gerarPedido();
}

function draw() {
  background(180, 230, 180);
  desenharCenario();

  if (estado === "jogando") {
    jogador.mover();
    jogador.mostrar();

    // Criar alimentos
    if (frameCount % 100 === 0 && random() < 0.8) {
      let tipo = random(tipos);
      let x = random(50, width / 2 - 50);
      let y = random(height - 140, height - 60);
      alimentos.push(new Alimento(x, y, tipo));
    }

    // Mostrar alimentos e coletar
    for (let i = alimentos.length - 1; i >= 0; i--) {
      alimentos[i].mostrar();
      if (jogador.coletar(alimentos[i])) {
        let t = alimentos[i].tipo;
        inventario[t] = (inventario[t] || 0) + 1;
        alimentos.splice(i, 1);
      }
    }

    // Criar obstáculos
    if (frameCount % 80 === 0) {
      obstaculos.push(new Obstaculo());
    }

    for (let i = obstaculos.length - 1; i >= 0; i--) {
      obstaculos[i].mover();
      obstaculos[i].mostrar();
      if (jogador.colidiu(obstaculos[i])) {
        vidas--;
        obstaculos.splice(i, 1);
        if (vidas <= 0) estado = "fim";
      } else if (obstaculos[i].x < -50) {
        obstaculos.splice(i, 1);
      }
    }

    // Entregar
    if (jogador.x > cidadeX + 20) {
      if (pedidoAtendido()) {
        entregas++;
        removerPedidoDoInventario();
        gerarPedido();
      }
    }

    mostrarHUD();
  } else {
    textAlign(CENTER);
    textSize(32);
    fill(255);
    text("🌆 FIM DE JOGO\nEntregas feitas: " + entregas, width / 2, height / 2);
    textSize(16);
    text("Pressione ENTER para recomeçar", width / 2, height / 4 + 40);
  }
}

function keyPressed() {
  if (estado === "fim" && keyCode === ENTER) {
    entregas = 0;
    vidas = 3;
    inventario = {};
    alimentos = [];
    obstaculos = [];
    gerarPedido();
    jogador = new Trator();
    estado = "jogando";
  }
}

function desenharCenario() {
  fill(60, 160, 60);
  rect(0, height - 100, width / 2, 100);
  fill(255);
  text("🌾 Campo", 20, height - 110);

  fill(100);
  rect(width / 2, height - 100, width / 2, 100);

  fill(80);
  rect(cidadeX, height - 200, 150, 200);
  fill(255);
  text("🏙️ Cidade", cidadeX + 20, height - 210);
}

function mostrarHUD() {
  fill(0);
  textSize(16);
  text("Vidas: " + vidas, 20, 30);
  text("Entregas: " + entregas, 20, 50);

  let yInv = 70;
  text("📦 Estoque:", 20, yInv);
  for (let tipo of tipos) {
    let qtd = inventario[tipo] || 0;
    yInv += 20;
    text(tipo + " : " + qtd, 30, yInv);
  }

  // Pedido
  yInv += 30;
  text("📋 Pedido da Cidade:", 20, yInv);
  for (let tipo in pedidos[0]) {
    yInv += 20;
    text(tipo + " x " + pedidos[0][tipo], 30, yInv);
  }
}

function gerarPedido() {
  let pedido = {};
  let qtdTipos = floor(random(1, 3));
  let escolhidos = shuffle(tipos).slice(0, qtdTipos);
  for (let tipo of escolhidos) {
    pedido[tipo] = floor(random(1, 3));
  }
  pedidos = [pedido];
}

function pedidoAtendido() {
  let pedido = pedidos[0];
  for (let tipo in pedido) {
    if (!inventario[tipo] || inventario[tipo] < pedido[tipo]) {
      return false;
    }
  }
  return true;
}

function removerPedidoDoInventario() {
  let pedido = pedidos[0];
  for (let tipo in pedido) {
    inventario[tipo] -= pedido[tipo];
  }
}

// ==== CLASSES ====

class Trator {
  constructor() {
    this.x = 50;
    this.y = height - 80;
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) this.x -= 4;
    if (keyIsDown(RIGHT_ARROW)) this.x += 4;
    if (keyIsDown(UP_ARROW)) this.y -= 4;
    if (keyIsDown(DOWN_ARROW)) this.y += 4;

    this.x = constrain(this.x, 0, width - 50);
    this.y = constrain(this.y, height - 150, height - 40);
  }

  mostrar() {
    textSize(28);
    text("🚜", this.x, this.y);
  }

  coletar(alimento) {
    return dist(this.x, this.y, alimento.x, alimento.y) < 30;
  }

  colidiu(obs) {
    return (
      this.x < obs.x + obs.w &&
      this.x + 40 > obs.x &&
      this.y < obs.y + obs.h &&
      this.y + 30 > obs.y
    );
  }
}

class Alimento {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
  }

  mostrar() {
    textSize(22);
    text(this.tipo, this.x, this.y);
  }
}

class Obstaculo {
  constructor() {
    this.x = width;
    this.y = random(height - 130, height - 60);
    this.w = 30;
    this.h = 20;
    this.v = 4;
  }

  mover() {
    this.x -= this.v;
  }

  mostrar() {
    textSize(22);
    text("💥", this.x, this.y);
  }
}
